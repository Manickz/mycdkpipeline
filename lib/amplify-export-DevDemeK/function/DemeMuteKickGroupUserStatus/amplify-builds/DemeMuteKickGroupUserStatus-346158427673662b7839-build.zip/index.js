const AWS = require("aws-sdk");
const moment = require("moment");

async function deleteEvents(ruleName, region, eventBus = "default") {
  AWS.config.update({ region: region });
  // Create CloudWatchEvents service object
  var ebevents = new AWS.EventBridge({ apiVersion: "2015-10-07" });

  // list targets
  var list_params = { Rule: ruleName };
  var targetData = await ebevents.listTargetsByRule(list_params).promise();
  const targetIds = targetData.Targets.map(({ Id }) => Id);
  console.log("targetids::", targetIds);

  //remove targets
  var remove_target_params = { Rule: ruleName, Ids: targetIds };
  const deleteTargets = await ebevents
    .removeTargets(remove_target_params)
    .promise();
  console.log(deleteTargets);

  // delete rule
  var rule_params = { Name: ruleName };
  const data1 = await ebevents.deleteRule(rule_params).promise();
  console.log("Deleting eb rule::", data1);
}

exports.handler = async (event, context) => {
  console.log(`EVENT: ${JSON.stringify(event)}`);
  var triggerbyScheduler = false;
  let is_active_params = false;
  try {
    let mute_user_request = undefined;
    if (event.body === undefined) {
      // instant events
      mute_user_request = JSON.parse(event.detail.muteData);
    } else {
      // events based on scheduler
      triggerbyScheduler = true;
      mute_user_request = JSON.parse(event.body);
    }

    const documentclient = new AWS.DynamoDB.DocumentClient({
      region: process.env.REGION,
    });
    // get the Group data based on Secondary index
    let conditionExpression = "userID = :hashKey";
    let get_data_attributeValues = {
      ":hashKey": mute_user_request.muteUserId,
    };
    const get_data_params = {
      TableName: process.env.GroupUserConnectionTable,
      IndexName: process.env.GroupUserConnectionIndex,
      KeyConditionExpression: conditionExpression,
      ExpressionAttributeValues: get_data_attributeValues,
    };
    const get_user_data = await documentclient.query(get_data_params).promise();
    console.log(get_user_data);
    console.log(get_user_data["Items"][0]["id"]);

    if (mute_user_request.mute_type === "permanent_kick") {
      const delete_user_params = {
        TableName: process.env.GroupUserConnectionTable,
        Key: { id: get_user_data["Items"][0]["id"] },
      };
      const data = await documentclient.delete(delete_user_params).promise();
      console.log("User Deleted");
    } else {
      if (mute_user_request.action == "end_mute") {
        is_active_params = true;
      }
      // dynamodb table data change
      let last_changed = moment.now();
      let updated_time = moment.utc().format();
      let updateExpression =
        "set #isActive =:S, #updatedAt= :U, #lastchanged = :C, #version = #version + :N, #ismuted = :M, #mutedDuration = :D, #muteReason = :R";
      let expressionAttributeNames = {
        "#isActive": "isActive",
        "#updatedAt": "updatedAt",
        "#lastchanged": "_lastChangedAt",
        "#version": "_version",
        "#ismuted": "isMuted",
        "#mutedDuration": "mutedDuration",
        "#muteReason": "muteReason",
      };
      let attributeValues = {
        ":S": is_active_params,
        ":U": updated_time,
        ":C": last_changed,
        ":N": 1,
        ":M": !is_active_params,
        ":D":
          mute_user_request.endTime == undefined
            ? moment.now() // if endTime is undefined then giving a default value
            : moment.utc(mute_user_request.endTime).valueOf(),
        ":R": mute_user_request.muteReason,
      };
      const params = {
        TableName: process.env.GroupUserConnectionTable,
        Key: { id: get_user_data["Items"][0]["id"] },
        UpdateExpression: updateExpression,
        ExpressionAttributeNames: expressionAttributeNames,
        ExpressionAttributeValues: attributeValues,
        ReturnValues: "UPDATED_NEW",
      };
      const user_data = await documentclient.update(params).promise();
      console.log(user_data);
      console.log("User Muted/Unmuted");
    }
    if (triggerbyScheduler) {
      //dekete the event rule and targets
      const rule_name =
        mute_user_request.groupId +
        "-" +
        mute_user_request.muteUserId.split("-")[0] +
        "-" +
        mute_user_request.action;
      await deleteEvents(rule_name, process.env.REGION);
    }
    return {
      statusCode: 200,
      body: "User Mute/Unmute Actions Successful",
    };
  } catch (err) {
    console.log(err);
    throw err;
  }
};
