const AWS = require("aws-sdk");
const moment = require("moment");

exports.handler = async (event, context) => {
  console.log(`EVENT: ${JSON.stringify(event)}`);
  console.log(`Context: ${JSON.stringify(context)}`);
  try {
    let invite_code_request = event.arguments;
    // if (event.body === undefined) {
    //     invite_code_request = JSON.parse(event.arguments.code);
    // } else {
    //     invite_code_request = JSON.parse(event.body);
    // }

    const documentclient = new AWS.DynamoDB.DocumentClient({
      region: process.env.REGION ?? "ap-southeast-1",
    });

    let conditionExpression = "code = :hashKey AND #status = :codestatus";
    let get_data_attributeValues = {
      ":hashKey": invite_code_request.code,
      ":codestatus": "active"
    };
    const get_data_params = {
      TableName: "InviteCode-jwjmlknufvfgjjjbc336c7hssu-dev",
      FilterExpression: conditionExpression,
      ExpressionAttributeNames: { "#status": "status" },
      ExpressionAttributeValues: get_data_attributeValues,
    };
    const get_user_data = await documentclient.scan(get_data_params).promise();
    console.log(get_user_data);
    //console.log(get_user_data["Items"][0]["id"]);

    if (get_user_data && get_user_data["Items"].length > 0) {
      let itemId = get_user_data["Items"][0]["id"];
      // dynamodb table data change
      let last_changed = moment.now();
      let updated_time = moment.utc().format();
      let updateExpression =
        "set #updatedAt= :U, #lastchanged = :C, #version = #version + :N, #newstatus = :M";
      let expressionAttributeNames = {
        "#updatedAt": "updatedAt",
        "#lastchanged": "_lastChangedAt",
        "#version": "_version",
        "#newstatus": "status",
      };
      let attributeValues = {
        ":U": updated_time,
        ":C": last_changed,
        ":N": 1,
        ":M": "used",
      };
      const params = {
        TableName: "InviteCode-jwjmlknufvfgjjjbc336c7hssu-dev",
        Key: { id: itemId },
        UpdateExpression: updateExpression,
        ExpressionAttributeNames: expressionAttributeNames,
        ExpressionAttributeValues: attributeValues,
        ReturnValues: "UPDATED_NEW",
      };
      const invite_data = await documentclient.update(params).promise();
      console.log(invite_data);
      console.log("invite code used");
      return {
        status: 200,
        body: itemId,
      };
    }else{
        return {
            status: 404,
            body: "invalid invite code",
        };
    }
   
  } catch (err) {
    console.log(err);
    throw err;
  }
};
