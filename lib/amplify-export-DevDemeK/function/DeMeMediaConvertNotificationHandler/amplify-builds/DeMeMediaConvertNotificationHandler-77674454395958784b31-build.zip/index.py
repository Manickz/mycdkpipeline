import os
import json
import boto3
from urllib.parse import unquote
from datetime import datetime
from datetime import timezone

def handler(event, context):
    try:
        streaming_s3_url = None
        database = boto3.resource('dynamodb')
        table = database.Table(os.environ.get('PostTable'))
        post_id = event['detail']['userMetadata']['PostId']
        output_groups = event['detail']['outputGroupDetails']
        print('outputGroups::', output_groups)
        streaming_outputs = next(filter(
            lambda output_groups: output_groups['type'] == 'HLS_GROUP', output_groups), None)
        print('streaming Outputs::', streaming_outputs)

        if streaming_outputs is None:
            print('unable to find HLS streaming Group')
            return {
                'statusCode': 300,
                'body': 'Unable to find the HLS streaming Group in the MediaConvert Outputs'
            }

        if 'playlistFilePaths' in streaming_outputs and len(streaming_outputs.get('playlistFilePaths')) > 0:
            streaming_s3_url = streaming_outputs.get('playlistFilePaths')[0]

        if streaming_s3_url is None:
            print('unable to find HLS streaming S3 Url')
            return {
                'statusCode': 300,
                'body': 'Unable to find the HLS streaming S3 Url in the MediaConvert Outputs'
            }
        print(streaming_s3_url)

        runtime_region = os.environ['AWS_REGION']
        s3_object_url = streaming_s3_url.replace("s3://", "")
        bucket_name, key_path = s3_object_url.split("/", 1)
        # Replace with the appropriate S3 endpoint
        s3_endpoint = "s3." + runtime_region + ".amazonaws.com"
        https_s3_uri = f"https://{bucket_name}.{s3_endpoint}/{key_path}"

        print(https_s3_uri)
        updated_time = datetime.utcnow().isoformat()[:-3]+'Z'
        last_changed = int( datetime.now(timezone.utc).timestamp() * 1000)
        table.update_item(Key={'id': post_id},
                          UpdateExpression='set #cid =:S, #updatedAt= :U, #lastchanged = :C, #version = #version + :N',
                          ExpressionAttributeNames={"#cid": "cid", "#updatedAt":"updatedAt", "#lastchanged":"_lastChangedAt", "#version":"_version"},
                          ExpressionAttributeValues={':S': https_s3_uri, ':U': updated_time, ':C': last_changed, ':N': 1},
                          ReturnValues="UPDATED_NEW")

        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
            },
            'body': json.dumps('Hello from your new Amplify Python lambda!')
        }
    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'body': str(e)
        }
