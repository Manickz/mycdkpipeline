import json
import os
from urllib.parse import urlparse
import uuid
import boto3
from urllib.parse import unquote


def handler(event, context):

    result_list = []
    result_code = 'Succeeded'
    result_string = 'The input video object was converted successfully.'

    invocation_id = str(uuid.uuid4())
    print(event)
    source_s3_key = unquote(event['Records'][0]['s3']['object']['key'])
    post_id = None
    print(source_s3_key)
    source_s3_bucket = event['Records'][0]['s3']['bucket']['name']
    print(source_s3_bucket)
    source_s3 = 's3://' + source_s3_bucket + '/' + source_s3_key

    # getting the tags from the s3 object
    s3_client = boto3.client('s3')
    object_head = s3_client.head_object(
        Bucket=source_s3_bucket, Key=source_s3_key)
    print(object_head)
    if 'video' not in object_head['ContentType']:
        result_list.append({
            'resultCode': 'Permanent Failure',
            'resultString': 'Uploaded files are not of video format',
        })
        print(result_list)
        return {
            'treatMissingKeyAs': 'PermanentFailure',
            'invocationId': invocation_id,
            'results': result_list
        }
    if 'Metadata' in object_head:
        post_id = object_head['Metadata']['postid']
        print(post_id)
    # changing the postid data from tags to metadata
    ''' object_tags = s3_client.get_object_tagging(Bucket=source_s3_bucket,Key=source_s3_key)
    if 'TagSet' in object_tags:
        result = next(filter(lambda d: d.get('Key') == 'PostId' , object_tags['TagSet']), None)
        if result is not None:
            post_id = result.get('Value')
            print(post_id) '''

    if post_id is None:
        result_list.append({
            'resultCode': 'Permanent Failure',
            'resultString': 'Tags were not present in the Video uploaded',
        })
        print(result_list)
        return {
            'treatMissingKeyAs': 'PermanentFailure',
            'invocationId': invocation_id,
            'results': result_list
        }

    # The type of output group determines which media players can play
    # the files transcoded by MediaConvert.
    # For more information, see Creating outputs with AWS Elemental MediaConvert.
    output_group_type_dict = {
        'HLS_GROUP_SETTINGS': 'HlsGroupSettings',
        'FILE_GROUP_SETTINGS': 'FileGroupSettings',
        'CMAF_GROUP_SETTINGS': 'CmafGroupSettings',
        'DASH_ISO_GROUP_SETTINGS': 'DashIsoGroupSettings',
        'MS_SMOOTH_GROUP_SETTINGS': 'MsSmoothGroupSettings'
    }

    try:
        job_name = 'Default'
        with open('job.json') as file:
            job_settings = json.load(file)

        job_settings['Inputs'][0]['FileInput'] = source_s3

        # The path of each output video is constructed based on the values of
        # the attributes in each object of OutputGroups in the job.json file.
        destination_s3 = 's3://{0}/{1}/{2}' \
            .format(os.environ['DestinationBucket'],
                    os.path.splitext(os.path.basename(source_s3_key))[0],
                    os.path.splitext(os.path.basename(job_name))[0])

        for output_group in job_settings['OutputGroups']:
            output_group_type = output_group['OutputGroupSettings']['Type']
            if output_group_type in output_group_type_dict.keys():
                output_group_type = output_group_type_dict[output_group_type]
                output_group['OutputGroupSettings'][output_group_type]['Destination'] = \
                    "{0}{1}".format(destination_s3,
                                    urlparse(output_group['OutputGroupSettings'][output_group_type]['Destination']).path)
            else:
                raise ValueError("Exception: Unknown Output Group Type {}."
                                 .format(output_group_type))

        job_metadata_dict = {
            'assetID': invocation_id,
            'application': os.environ['Application'],
            'input': source_s3,
            'settings': job_name,
            'PostId': post_id
        }

        print(job_metadata_dict)

        region = os.environ['AWS_DEFAULT_REGION']
        endpoints = boto3.client('mediaconvert', region_name=region) \
            .describe_endpoints()
        client = boto3.client('mediaconvert', region_name=region,
                              endpoint_url=endpoints['Endpoints'][0]['Url'],
                              verify=False)

        try:
            client.create_job(Role=os.environ['MediaConvertRole'],
                              UserMetadata=job_metadata_dict,
                              Settings=job_settings,
                              Tags={'assetId': job_metadata_dict['assetID']})

            # if success insert into the dynamodb
        # You can customize error handling based on different error codes that
        # MediaConvert can return.
        # For more information, see MediaConvert error codes.
        # When the result_code is TemporaryFailure, S3 Batch Operations retries
        # the task before the job is completed. If this is the final retry,
        # the error message is included in the final report.
        except Exception as error:
            result_code = 'TemporaryFailure'
            raise

    except Exception as error:
        if result_code != 'TemporaryFailure':
            result_code = 'PermanentFailure'
        result_string = str(error)

    finally:
        result_list.append({
            'resultCode': result_code,
            'resultString': result_string,
        })
    print(result_list)
    return {
        'treatMissingKeyAs': 'PermanentFailure',
        'invocationId': invocation_id,
        'results': result_list
    }
