/* Amplify Params - DO NOT EDIT
  API_DEVDEMEK_GRAPHQLAPIENDPOINTOUTPUT
  API_DEVDEMEK_GRAPHQLAPIIDOUTPUT
  API_DEVDEMEK_GRAPHQLAPIKEYOUTPUT
  AUTH_DEVDEMEK_USERPOOLID
  ENV
  REGION
Amplify Params - DO NOT EDIT */

const AWS = require('aws-sdk');
const { Alchemy, Network } = require("alchemy-sdk");
const ethers = require("ethers");
const fetch = require('node-fetch');
const awscrypto = require('@aws-crypto/sha256-js');
const { defaultProvider } = require('@aws-sdk/credential-provider-node');
const { SignatureV4 } = require('@aws-sdk/signature-v4');
const { HttpRequest } = require('@aws-sdk/protocol-http');
const { Sha256 } = awscrypto;
const AmazonCognitoIdentity = require('amazon-cognito-identity-js');
const CognitoUserPool = AmazonCognitoIdentity.CognitoUserPool;
const CognitoUserAttribute = AmazonCognitoIdentity.CognitoUserAttribute;
const ERC20 = require('./IERC20.json');
const ERC721 = require('./IERC721.json');
const ERC1155 = require('./IERC1155.json');
const crypto = require("crypto");

const GRAPHQL_ENDPOINT = process.env.API_DEVDEMEK_GRAPHQLAPIENDPOINTOUTPUT;
//const GRAPHQL_API_KEY = process.env.API_DEVDEMEK_GRAPHQLAPIKEYOUTPUT;
const AWS_REGION = process.env.AWS_REGION || 'us-east-1';
const ALCHEMY_API_URL = process.env.ALCHEMY_API_URL || 'https://eth-mainnet.g.alchemy.com/v2/3ifWyfOPsbkNu3J-q65b6gjwjqDKCPSq';
const POLYGON_API_URL = process.env.POLYGON_API_URL || 'https://polygon-mainnet.g.alchemy.com/v2/aUhmTpzM04NYf8Zg_tTOvPHBqFZ3zKzq';
const WALLET_PRIVATE_KEY = process.env.WALLET_PRIVATE_KEY || 'd1b03636beb723aa951c4bf376315e51392151d39b2ad6324732f7166995a902';

const ETHERSCAN_API_KEY = process.env.ETHERSCAN_API_KEY || '82ZRATXF8YDNB1PNCPFYQB7ZWCG33Y1BDC';
const POLYSCAN_API_KEY = process.env.POLYSCAN_API_KEY || '832S7H4AJ2CGBQ7GWTJ454RA636FKGENJ6';
const ETHERSCAN_DOMAIN = process.env.ETHERSCAN_DOMAIN || 'https://api.etherscan.io';
const POLYSCAN_DOMAIN = process.env.POLYSCAN_DOMAIN || 'https://api.polygonscan.io';

const provider = ethers.getDefaultProvider(ALCHEMY_API_URL);
// get the smart contract
const contractWallet = new ethers.Wallet(WALLET_PRIVATE_KEY, provider);

const polygonprovider = ethers.getDefaultProvider(POLYGON_API_URL);
// get the smart contract
const contractWallet2 = new ethers.Wallet(WALLET_PRIVATE_KEY, polygonprovider);

const endpoint = new URL(GRAPHQL_ENDPOINT);

const signer = new SignatureV4({
  credentials: defaultProvider(),
  region: AWS_REGION,
  service: 'appsync',
  sha256: Sha256
});

const ethapikey =  process.env.ETH_API_KEY || "3ifWyfOPsbkNu3J-q65b6gjwjqDKCPSq";
const polyapikey = process.env.POLY_API_KEY || "aUhmTpzM04NYf8Zg_tTOvPHBqFZ3zKzq";

const ethnetwork = process.env.ETH_NETWORK || Network.ETH_MAINNET;
const polygonnet = process.env.POLY_NETWORK || Network.MATIC_MAINNET;

const config = {
  apiKey: ethapikey,
  network: ethnetwork
};
const alchemyeth = new Alchemy(config);

const polyconfig = {
  apiKey: polyapikey,
  network: polygonnet,
};
const alchemypoly = new Alchemy(polyconfig);

var poolData = {
  "UserPoolId": "ap-southeast-1_pz8Aejspk",
  "ClientId": "5e0ctbi505s7verkuprhvjbsb5"
};

var userPool = new CognitoUserPool(poolData);

const query = /* GraphQL */ `
  mutation CREATE_GROUP($input: CreateGroupInput!) {
    createGroup(input: $input) {
      id
      name
      createdAt
    }
  }
`;

const relationmutation = /* GraphQL */ `
  mutation CREATE_RELATION($input: CreateUserGroupRelationInput!) {
    createUserGroupRelation(input: $input) {
      id
      createdAt
    }
  }
`;

const createuser = /* GraphQL */ `
  mutation CREATE_USER($input: CreateUserInput!) {
    createUser(input: $input) {
      id
      createdAt
    }
  }
`;

const createwallet = /* GraphQL */ `
  mutation CREATE_WALLET($input: CreateWalletInput!) {
    createWallet(input: $input) {
      id
      createdAt
    }
  }
`;


const userPoolSignup = (walletaddress, signature, attributeList) => {
  return new Promise((resolve, reject) => {
    userPool.signUp(walletaddress, signature, attributeList, null, (err, data) => {
      if (err) return reject(err)
      resolve(data)
    })
  })
}


const signupUser = async (walletaddress) => {
  var attributeList = [];
  var dataWalletAddress = {
    Name: 'custom:userAddress',
    Value: walletaddress,
  };

  var signature = crypto.randomBytes(20).toString('hex');
  
  var dataSignature = {
    Name: 'custom:walletSignature',
    Value: signature,
  };
  var attributeuserAddress = new AmazonCognitoIdentity.CognitoUserAttribute(dataWalletAddress);
  var attributewalletSignature = new AmazonCognitoIdentity.CognitoUserAttribute(
    dataSignature
  );

  attributeList.push(attributeuserAddress);
  attributeList.push(attributewalletSignature);

  try {
    var result = await userPoolSignup(walletaddress, signature, attributeList);
    return result.userSub;
  }catch(e){
    console.log(e);
    return null;
  }
}

/**
 * @type {import('@types/aws-lambda').APIGatewayProxyHandler}
 */
exports.handler = async (event) => {

  console.log(`EVENT: ${JSON.stringify(event)}`);
  

  for (const record of event.Records) {
    console.log(record.eventID);
    console.log(record.eventName);
    console.log('DynamoDB Record: %j', record.dynamodb);
    let newimage = AWS.DynamoDB.Converter.unmarshall(record.dynamodb.NewImage);
    const walletaddress = newimage.address;
    createGroupsByChain(walletaddress, "ETH");
    createGroupsByChain(walletaddress, "POLYGON");
  }
  return Promise.resolve('Successfully processed DynamoDB record');
};

const createGroupsByChain = async (walletaddress, chain) => {
    let alchemy;
    if(chain == "ETH"){
      alchemy = alchemyeth;
    }else if(chain == "POLYGON"){
      alchemy = alchemypoly;
    }

    const balances = await alchemy.core.getTokenBalances(walletaddress);
    const nonZeroBalances = balances.tokenBalances.filter((token) => {
      return token.tokenBalance !== "0";
    });

    var network = await alchemy.core.getNetwork();
    var chainId = network.chainId;

    //const signed = await signer.sign(requestToBeSigned);

    var tokenAddresses = nonZeroBalances.map(e => e.contractAddress);

    creategroups(newimage, tokenAddresses, chainId, "ERC20");

    const nfts = await alchemy.nft.getNftsForOwner(walletaddress);
    const ownednfts = nfts.ownedNfts;
    const nonZeroBalances2 = ownednfts.filter((nft) => {
      return nft.balance != 0 && nft.tokenType == "ERC721";
    });

    var tokenAddresses2 = nonZeroBalances2.map(e => e.contract.address);
    creategroups(newimage, tokenAddresses2, chainId, "ERC721");

    const nonZeroBalances3 = ownednfts.filter((nft) => {
      return nft.balance != 0 && nft.tokenType == "ERC1155";
    });

    var tokenAddresses3 = nonZeroBalances3.map(e => e.contract.address);
    creategroups(newimage, tokenAddresses3, chainId, "ERC1155");
}

const creategroups = async (newimage, tokenAddresses, chainId, tokenType) => {
  var contractownermap = {};
  var notfoundOwner = [];
  var abi = tokenType == "ERC20" ? ERC20.abi : tokenType == "ERC721" ? ERC721.abi : ERC1155.abi;
  let contractrunner;
  if(chainId == 1){
    contractrunner = contractWallet;
  }else{
    contractrunner = contractWallet2;
  }
  for(let tokenAddress of tokenAddresses){
    const contract = new ethers.Contract(
      tokenAddress,
      abi,
      contractrunner
    );

    try {
      let contractowner = await contract.owner();
      contractownermap[tokenAddress] = contractowner;
    }catch(e){
      notfoundOwner.push(tokenAddress);
    }
  }

  var chunks = [];
  
  while (notfoundOwner.length > 0){
    chunks.push(notfoundOwner.splice(0, 5));
  }

  for(let chunk of chunks){
    let chunkstr = chunk.join(",");
    let url;
    if (chainId == 1) {
      url = `${ETHERSCAN_DOMAIN}/api?module=contract&action=getcontractcreation&contractaddresses=${chunkstr}&apikey=${ETHERSCAN_API_KEY}`;
    } else {
      url = `${POLYSCAN_DOMAIN}/api?module=contract&action=getcontractcreation&contractaddresses=${chunkstr}&apikey=${POLYSCAN_API_KEY}`;
    }
    
    let res = await fetch(url);
    let bodyjson = await res.json();
    console.log(bodyjson);
    if(bodyjson.result != null && bodyjson.result.length > 0){
      for(let i = 0; i < bodyjson.result.length; i++ ){
        let result = bodyjson.result[i];
        let contractaddress = result.contractAddress;
        contractownermap[contractaddress] = result.contractCreator;
      }
    }
  }

  for (let token of nonZeroBalances) {
    var tokenAddress = token.contractAddress;
    const documentclient = new AWS.DynamoDB.DocumentClient({
      region: process.env.REGION ?? "ap-southeast-1",
    });

    let conditionExpression = "tokenAddress = :hashKey AND chainId = :chainid";
    let get_data_attributeValues = {
      ":hashKey": tokenAddress,
      ":chainid": chainId
    };
    const get_data_params = {
      TableName: "Group-jwjmlknufvfgjjjbc336c7hssu-dev",
      FilterExpression: conditionExpression,
      ExpressionAttributeValues: get_data_attributeValues,
      Limit: 1
    };
    const get_group_data = await documentclient.scan(get_data_params).promise();
    console.log(get_group_data.Items);
    if (get_group_data) {
      if (!get_group_data.Items || get_group_data.Items.length == 0) {
        let contractowner  = contractownermap[tokenAddress];

        console.log("contractowner "+ contractowner);

        if (contractowner) {
          let conditionExpression = "address = :hashKey";
          let get_data_attributeValues = {
            ":hashKey": contractowner,
          };
          const get_data_params1 = {
            TableName: "Wallet-jwjmlknufvfgjjjbc336c7hssu-dev",
            FilterExpression: conditionExpression,
            ExpressionAttributeValues: get_data_attributeValues,
            Limit: 1
          };
          const get_user_data = await documentclient.scan(get_data_params1).promise();

          let authorid;
          let docowner;

          if (get_user_data?.Items && get_user_data.Items.length > 0) {
            authorid = get_user_data.Items[0].userID;
            docowner = `${get_user_data.Items[0].userID}::${contractowner}`;

          } else {
            var userid = await signupUser(contractowner);
            if(userid != null){
              docowner = `${userid}::${contractowner}`;
              const uservariables = {
                input: {
                  id: userid,
                  userAddress: contractowner,
                  owner: docowner
                }
              };

              const userrequestToBeSigned = new HttpRequest({
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  host: endpoint.host
                },
                hostname: endpoint.host,
                body: JSON.stringify({ query: createuser, variables: uservariables }),
                path: endpoint.pathname
              });

              const signeduserreq = await signer.sign(userrequestToBeSigned);

              //const request = new nodefetch.Request(GRAPHQL_ENDPOINT, options);
              let userresponse = await fetch(GRAPHQL_ENDPOINT, signeduserreq);
              let userbody = await userresponse.json();
              if(userbody.data.createUser.id){
                const walletvariables = {
                  input: {
                    address: contractowner,
                    userID: userid,
                    owner: docowner
                  }
                };
  
                const walletrequestToBeSigned = new HttpRequest({
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                    host: endpoint.host
                  },
                  hostname: endpoint.host,
                  body: JSON.stringify({ query: createwallet, variables: walletvariables }),
                  path: endpoint.pathname
                });
  
                const signedwalletreq = await signer.sign(walletrequestToBeSigned);
  
                //const request = new nodefetch.Request(GRAPHQL_ENDPOINT, options);
                let walletresponse = await fetch(GRAPHQL_ENDPOINT, signedwalletreq);
              }
            }
          }
          
          const metadata = await alchemy.core.getTokenMetadata(tokenAddress);
          var groupname = metadata.name;
          let variables;
          if(authorid && docowner){
            variables = {
              input: {
                name: groupname,
                tokenAddress: tokenAddress,
                tokenType: tokenType,
                chainId: chainId,
                authorID: authorid,
                owner: docowner
              }
            };
          }else {
            variables = {
              input: {
                name: groupname,
                tokenAddress: tokenAddress,
                tokenType: tokenType,
                chainId: chainId
              }
            };
          }

          const requestToBeSigned = new HttpRequest({
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              host: endpoint.host
            },
            hostname: endpoint.host,
            body: JSON.stringify({ query, variables }),
            path: endpoint.pathname
          });

          const signed = await signer.sign(requestToBeSigned);

          //const request = new nodefetch.Request(GRAPHQL_ENDPOINT, options);
          let response = await fetch(GRAPHQL_ENDPOINT, signed);
          let body = await response.json();
          console.log(body);
          if (body && body.data?.createGroup?.id) {
            const relationvariables = {
              input: {
                userID: newimage.userID,
                groupUuid: body.data.createGroup.id,
                typeofRelation: newimage.userID == get_user_data.Items[0].userID ? "admin" : "member",
                isActive: true
              }
            };

            const requestToBeSigned2 = new HttpRequest({
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                host: endpoint.host
              },
              hostname: endpoint.host,
              body: JSON.stringify({ query: relationmutation, variables: relationvariables }),
              path: endpoint.pathname
            });

            const signed2 = await signer.sign(requestToBeSigned2);
            let response2 = await fetch(GRAPHQL_ENDPOINT, signed2);
            let body2 = await response2.json();
            console.log(body2);
          }
        }
      } else if (get_group_data.Items.length > 0) {
        const relationvariables = {
          input: {
            userID: newimage.userID,
            groupUuid: get_group_data.Items[0].id,
            typeofRelation: "member",
            isActive: true
          }
        };

        const requestToBeSigned2 = new HttpRequest({
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            host: endpoint.host
          },
          hostname: endpoint.host,
          body: JSON.stringify({ query: relationmutation, variables: relationvariables }),
          path: endpoint.pathname
        });

        const signed2 = await signer.sign(requestToBeSigned2);
        let response2 = await fetch(GRAPHQL_ENDPOINT, signed2);
        let body2 = await response2.json();
        console.log(body2);
      }
    }

  }
}