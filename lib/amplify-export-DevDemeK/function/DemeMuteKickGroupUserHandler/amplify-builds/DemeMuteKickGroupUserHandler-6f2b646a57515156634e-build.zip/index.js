const AWS = require("aws-sdk");
const moment = require("moment");

async function putEventSchedulerRule(
  ruleName,
  region,
  targetData,
  expression,
  targetServiceArn,
  eventBus = "default"
) {
  try {
    // Set the region
    AWS.config.update({ region: region });

    // Create CloudWatchEvents service object
    var ebevents = new AWS.EventBridge({ apiVersion: "2015-10-07" });
    var lambda = new AWS.Lambda({ apiVersion: "2015-10-07" });

    var rule_params = {
      Name: ruleName, //'DEMO_EVENT',
      //RoleArn: 'IAM_ROLE_ARN',
      ScheduleExpression: expression, //'rate(5 minutes)',
      State: "ENABLED",
    };
    var rule_arn = "";

    const data1 = await ebevents.putRule(rule_params).promise();
    rule_arn = data1.RuleArn;
    console.log("Success", rule_arn);

    var params = {
      Rule: ruleName, //'DEMO_EVENT',
      Targets: [
        {
          Arn: targetServiceArn, //'arn:aws:lambda:ap-south-1:445612755799:function:freetrade-bootupfunctions-dev-initClientCredentials',
          Id: ruleName + "_id", // 'myEventBridgeTarget',
          Input: JSON.stringify({ body: targetData }),
        },
      ],
    };
    const data_target1 = await ebevents.putTargets(params).promise();
    console.log(data_target1);
  } catch (error) {
    console.log(error);
    throw error;
  }
}

async function putEvents(region, paramsObj, eventBus = "default") {
  try {
    AWS.config.update({ region: region });

    // Create CloudWatchEvents service object
    var ebevents = new AWS.EventBridge({ apiVersion: "2015-10-07" });
    var params = {
      Entries: [
        {
          Detail: JSON.stringify(paramsObj),
          Source: "custom",
          EventBusName: eventBus,
          DetailType: "custom to put event in eventbridge",
        },
      ],
    };
    const data = await ebevents.putEvents(params).promise();
    return data;
    /* ebevents.putEvents(params, function (err, data) {
          if (err) { console.log(err, err.stack); }// an error occurred
          else {
              console.log(data);
              return data;
          }   // successful response
      });*/
  } catch (error) {
    console.log(error);
    throw error;
  }
}

exports.handler = async (event) => {
  console.log(`EVENT: ${JSON.stringify(event)}`);
  console.log("Got an Invoke Request.");
  const documentclient = new AWS.DynamoDB.DocumentClient({
    region: process.env.REGION,
  });
  var request = event.arguments.input;
  const groupId = request.groupId;
  const userId = request.userId;
  const muteUserId = request.muteUserId.split("-")[0];
  const muteStartTime =
    request.startTime !== undefined
      ? moment(request.startTime)
      : request.startTime;
  const muteEndTime =
    request.endTime !== undefined ? moment(request.endTime) : request.endTime;
  const mute_reason =
    request.muteReason !== undefined ? request.muteReason : "";
  // Check if the user is admin
  var conditionExpression = "groupUuid = :hashKey";
  var attributeValues = {
    ":hashKey": groupId,
  };
  const params = {
    TableName: process.env.GroupUserConnectionTable,
    IndexName: process.env.GroupUserConnectionIndex,
    KeyConditionExpression: conditionExpression,
    ExpressionAttributeValues: attributeValues,
  };
  try {
    const data = await documentclient.query(params).promise();
    console.log(data);
    var requestedUser = data.Items.find((x) => x.userID == userId);
    console.log(`requestedUser: ${requestedUser}`);

    // if admin send the event to mute immediately if the start time is not passed , else create cron
    if (
      requestedUser !== undefined &&
      requestedUser.typeofRelation == "admin"
    ) {
      if (muteStartTime === undefined) {
        // send events immediately
        var muteUserEvent = {};
        muteUserEvent.actionType = "muteUser";
        muteUserEvent.Id = Math.floor(Math.random() * (1000 - 1 + 1) + 1);
        muteUserEvent.muteData = JSON.stringify(request);
        muteUserEvent.muteReason = mute_reason;
        var response_start_mute_instant = await putEvents(
          process.env.REGION,
          muteUserEvent
        );
        console.log(`response_start_mute_inst: ${response_start_mute_instant}`);
      } else {
        // create a cron expression for start mute event
        request.action = "start_mute";
        var time_hour = muteStartTime.hour();
        var time_minutes = muteStartTime.minutes();
        var mute_start_expression = `cron(${time_minutes} ${time_hour} ${muteStartTime.date()} ${muteStartTime.format(
          "MMMM"
        )} ? ${muteStartTime.year()})`;
        console.log(mute_start_expression);
        var response_start_mute = await putEventSchedulerRule(
          groupId + "-" + muteUserId + "-" + request.action,
          process.env.REGION,
          JSON.stringify(request),
          mute_start_expression,
          process.env.targetServiceArn
        );
        console.log(`response_start_mute: ${response_start_mute}`);
      }
      if (muteEndTime === undefined) {
        // do nothing
      } else {
        // create a cron expression for start mute event
        request.action = "end_mute";
        var time_hour_end = muteEndTime.hour();
        var time_minutes_end = muteEndTime.minutes();
        var mute_end_expression = `cron(${time_minutes_end} ${time_hour_end} ${muteEndTime.date()} ${muteEndTime.format(
          "MMMM"
        )} ? ${muteEndTime.year()})`;
        console.log(mute_end_expression);
        var response_end_mute = await putEventSchedulerRule(
          groupId + "-" + muteUserId + "-" + request.action,
          process.env.REGION,
          JSON.stringify(request),
          mute_end_expression,
          process.env.targetServiceArn
        );
        console.log(`response_end_mute: ${response_end_mute}`);
      }
      return {
        status: 200,
        body: "Events Created to Mute User",
      };
    } else {
      return {
        status: 300,
        body: "Only Admin can mute Users in the Group",
      };
    }
  } catch (err) {
    console.log(err);
    throw err;
  }
};
